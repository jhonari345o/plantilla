import { a, defineData, type ClientSchema } from "@aws-amplify/backend";

// Cada usuario de Cognito queda amarrado a una persona mediante "ownerId" (su ID de usuario).
// Las reglas las aplica AWS en el servidor: no se pueden saltar desde la consola del navegador.
const schema = a.schema({
  // Asistencia, selfies y viáticos que crean los empleados: ellos solo pueden CREAR y LEER lo suyo.
  // No pueden editar ni borrar. El administrador puede todo.
  Staff: a
    .model({ col: a.string().required(), json: a.string().required(), ownerId: a.string() })
    .authorization((allow) => [
      allow.group("admin"),
      allow.ownerDefinedIn("ownerId").to(["create", "read"]),
    ]),
  // Ficha de cada persona: el empleado solo lee la suya.
  Roster: a
    .model({ col: a.string().required(), json: a.string().required(), ownerId: a.string() })
    .authorization((allow) => [
      allow.group("admin"),
      allow.ownerDefinedIn("ownerId").to(["read"]),
    ]),
  // Configuración (tolerancia, selfies por día): todos leen, solo el administrador cambia.
  Config: a
    .model({ col: a.string().required(), json: a.string().required() })
    .authorization((allow) => [
      allow.group("admin"),
      allow.authenticated().to(["read"]),
    ]),
  // Facturas, ingresos, sueldos y correcciones de asistencia: solo administrador.
  Private: a
    .model({ col: a.string().required(), json: a.string().required() })
    .authorization((allow) => [allow.group("admin")]),
});

export type Schema = ClientSchema<typeof schema>;
export const data = defineData({
  schema,
  authorizationModes: { defaultAuthorizationMode: "userPool" },
});
