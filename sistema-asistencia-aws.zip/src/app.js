(function(){
"use strict";
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money=n=>"$"+(Number(n)||0).toFixed(2);
const pad=n=>String(n).padStart(2,"0");
const isoDate=d=>d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
const toMin=t=>{if(!t)return null;const [h,m]=t.split(":").map(Number);return h*60+m};
const nowHM=()=>{const d=new Date();return pad(d.getHours())+":"+pad(d.getMinutes())};
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove("show"),2400)}

/* ---------- Estado ---------- */
const S={salaries:{},employees:{},attendance:{},expenses:{},settings:{tolerance:0},selfies:{},invoices:{},income:{}};
const COLS=["salaries","employees","attendance","expenses","settings","selfies","invoices","income"];

/* ---------- Almacenamiento: db compartida o copia local ---------- */
const LKEY="asistencia-viaticos-v1";
const Store={mode:"local",db:null,
  idb(){return new Promise(r=>{try{const q=indexedDB.open("asist",1);q.onupgradeneeded=()=>q.result.createObjectStore("k");q.onsuccess=()=>r(q.result);q.onerror=()=>r(null)}catch(e){r(null)}})},
  async loadLocal(){const d=await this.idb();if(!d)return;await new Promise(r=>{const q=d.transaction("k").objectStore("k").get("S");q.onsuccess=()=>{const v=q.result;if(v)COLS.forEach(c=>{if(v[c])S[c]=v[c]});r()};q.onerror=()=>r()})},
  saveLocal(){clearTimeout(this._t);this._t=setTimeout(async()=>{const d=await this.idb();if(!d){toast("No se pudo guardar en este navegador.");return}d.transaction("k","readwrite").objectStore("k").put(S,"S")},150)},
  async set(col,id,data){
    if(this.mode==="db"){try{await this.db.collection(col).doc(id).set(data)}catch(e){toast(errMsg(e));throw e}}
    else{S[col][id]=data;this.saveLocal();renderAll()}
  },
  async del(col,id){
    if(this.mode==="db"){try{await this.db.collection(col).doc(id).delete()}catch(e){toast(errMsg(e));throw e}}
    else{delete S[col][id];this.saveLocal();renderAll()}
  }
};
function errMsg(e){const c=e&&e.code;
  if(c==="permission_denied"||c==="not_granted")return "No tienes permiso para guardar cambios aquí.";
  if(c==="too_large"||c==="invalid_argument")return "El archivo es demasiado grande. Prueba con otra foto.";
  return "No se pudo guardar. Intenta de nuevo.";}
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);

/* ---------- Reloj ---------- */
function tick(){const d=new Date();
  $("#clock").innerHTML=pad(d.getHours())+":"+pad(d.getMinutes())+"<small>"+pad(d.getSeconds())+"</small>";
  const s=d.toLocaleDateString("es-EC",{weekday:"long",day:"numeric",month:"long"});
  $("#dateLong").textContent=s.charAt(0).toUpperCase()+s.slice(1);}
tick();setInterval(tick,1000);

/* ---------- Cálculo ---------- */
function lateInfo(rec,emp){
  const expected=(rec._srv?null:rec.expected)||(emp&&emp.entry)||"08:30";
  if(!rec.arrival)return {expected,mins:null,charged:0,amount:0};
  const diff=toMin(rec.arrival)-toMin(expected);
  const tol=Number(S.settings.main?.tolerance ?? 0)||0;
  const mins=Math.max(0,diff);
  const charged=mins>tol?mins:0;
  const rate=Number(rec._srv?emp?.rate:(rec.rate ?? emp?.rate ?? 0))||0;
  return {expected,mins,charged,amount:charged*rate};
}
const sortedEmps=()=>Object.entries(S.employees).map(([id,e])=>({id,...e})).sort((a,b)=>(a.name||"").localeCompare(b.name||"","es"));
const attId=(date,empId)=>date+"_"+empId;

/* ---------- Tabs ---------- */
document.querySelectorAll("nav button").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll("nav button").forEach(x=>x.setAttribute("aria-selected",x===b?"true":"false"));
  ["asistencia","viaticos","informe","personal","campo","facturas","nomina","conta"].forEach(t=>$("#tab-"+t).hidden=(t!==b.dataset.tab));
}));

/* ---------- Asistencia ---------- */
const today=isoDate(new Date());
$("#attDate").value=today;
$("#attDate").addEventListener("change",renderAttendance);

function renderAttendance(){
  const date=$("#attDate").value||today;
  const emps=sortedEmps();const box=$("#attList");
  if(!emps.length){box.innerHTML='<div class="empty">Aún no hay personal. Agrégalo en la pestaña <strong>Personal</strong>.</div>';return}
  let lateCount=0;
  box.innerHTML=emps.map(e=>{
    const rec=S.attendance[attId(date,e.id)]||{};
    const li=lateInfo(rec,e);
    let stamp='<span class="stamp none">Sin marcar</span>';
    if(li.mins!==null){
      if(li.charged>0){stamp=`<span class="stamp late">${li.charged} min tarde · −${money(li.amount)}</span>`;if(date===today)lateCount++}
      else if(li.mins>0)stamp=`<span class="stamp ok">${li.mins} min (en tolerancia)</span>`;
      else stamp='<span class="stamp ok">A tiempo</span>';
    }
    return `<div class="person" data-emp="${esc(e.id)}">
      <div><div class="name">${esc(e.name)}</div><div class="exp">${money(e.rate)} por minuto</div></div>
      <div>${stamp}</div>
      <div class="times">
        <div><label>Entra a las</label><input type="time" class="in-exp" value="${esc(li.expected)}"></div>
        <div><label>Llegó a las</label><input type="time" class="in-arr" value="${esc(rec.arrival||"")}"></div>
        <button class="btn small mark">Marcar ahora</button>
      </div></div>`;
  }).join("");
  $("#lateToday").textContent=date===today?(lateCount?`${lateCount} con atraso hoy`:"Nadie con atraso hoy"):"";
}
$("#attList").addEventListener("click",e=>{
  if(!e.target.classList.contains("mark"))return;
  const row=e.target.closest(".person");row.querySelector(".in-arr").value=nowHM();saveAtt(row);
});
$("#attList").addEventListener("change",e=>{
  if(e.target.matches(".in-exp,.in-arr"))saveAtt(e.target.closest(".person"));
});
async function saveAtt(row){
  const empId=row.dataset.emp;const date=$("#attDate").value||today;const emp=S.employees[empId];
  const expected=row.querySelector(".in-exp").value||emp.entry;
  const arrival=row.querySelector(".in-arr").value;
  const id=attId(date,empId);
  if(!arrival&&expected===emp.entry){if(S.attendance[id])await Store.del("attendance",id);return}
  await Store.set("attendance",id,{empId,date,expected,arrival:arrival||"",rate:Number(emp.rate)||0,updatedAt:Date.now()});
  if(arrival)toast(`Registrado: ${emp.name} a las ${arrival}`);
}

/* ---------- Personal ---------- */
$("#pAdd").addEventListener("click",async()=>{
  const name=$("#pName").value.trim();if(!name){toast("Escribe el nombre.");$("#pName").focus();return}
  const entry=$("#pEntry").value||"08:30";const rate=Number($("#pRate").value)||0;
  await Store.set("employees",uid(),{name,entry,rate,uid:$("#pUid").value.trim(),createdAt:Date.now()});
  $("#pName").value="";$("#pUid").value="";toast(`${name} agregado`);
});
$("#tolSave").addEventListener("click",async()=>{
  await Store.set("settings","main",{tolerance:Math.max(0,parseInt($("#tol").value)||0)});toast("Tolerancia guardada");
});
function renderPeople(){
  $("#tol").value=S.settings.main?.tolerance??0;
  const emps=sortedEmps();const box=$("#peopleList");
  if(!emps.length){box.innerHTML='<div class="empty">Agrega a la primera persona arriba.</div>';return}
  box.innerHTML=emps.map(e=>`<div class="person" data-emp="${esc(e.id)}">
    <div class="name">${esc(e.name)}</div>
    <button class="btn small danger p-del">Quitar</button>
    <div class="times">
      <div><label>Entrada habitual</label><input type="time" class="p-entry" value="${esc(e.entry)}"></div>
      <div><label>$ por minuto</label><input type="number" class="p-rate" min="0" step="0.01" value="${esc(e.rate)}"></div>
      <div><label>ID de usuario AWS</label><input class="p-uid" value="${esc(e.uid||"")}" placeholder="User name de Cognito"></div>
    </div></div>`).join("");
}
$("#peopleList").addEventListener("change",async e=>{
  const row=e.target.closest(".person");if(!row)return;const id=row.dataset.emp;const emp=S.employees[id];
  await Store.set("employees",id,{...emp,entry:row.querySelector(".p-entry").value||emp.entry,rate:Number(row.querySelector(".p-rate").value)||0,uid:row.querySelector(".p-uid").value.trim()});
  toast("Cambios guardados");
});
$("#peopleList").addEventListener("click",async e=>{
  if(!e.target.classList.contains("p-del"))return;
  const id=e.target.closest(".person").dataset.emp;const emp=S.employees[id];
  if(!confirm(`¿Quitar a ${emp.name}? Sus registros anteriores se conservan en el informe.`))return;
  await Store.del("employees",id);
});

/* ---------- Viáticos ---------- */
$("#exDate").value=today;
$("#exMonth").value=today.slice(0,7);
function fillSelects(){
  const emps=sortedEmps();
  const opts=emps.map(e=>`<option value="${esc(e.id)}">${esc(e.name)}</option>`).join("");
  const keep1=$("#exEmp").value,keep2=$("#exFilter").value;
  $("#exEmp").innerHTML=opts||'<option value="">Agrega personal primero</option>';
  $("#exFilter").innerHTML='<option value="">Todos</option>'+opts;
  if(keep1&&S.employees[keep1])$("#exEmp").value=keep1;
  if(keep2&&S.employees[keep2])$("#exFilter").value=keep2;
}
function compressImage(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();r.onerror=()=>rej(new Error("read"));
    r.onload=()=>{const img=new Image();img.onerror=()=>rej(new Error("img"));
      img.onload=()=>{
        let max=1400,q=0.72,out="";
        for(let i=0;i<6;i++){
          const s=Math.min(1,max/Math.max(img.width,img.height));
          const c=document.createElement("canvas");c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);
          c.getContext("2d").drawImage(img,0,0,c.width,c.height);
          out=c.toDataURL("image/jpeg",q);
          if(out.length<220000)break;max=Math.round(max*0.8);q=Math.max(0.45,q-0.07);
        }
        res(out);};
      img.src=r.result;};
    r.readAsDataURL(file);
  });
}
$("#exSave").addEventListener("click",async()=>{
  const empId=$("#exEmp").value;if(!empId){toast("Primero agrega personal.");return}
  const amount=Number($("#exAmount").value);if(!(amount>0)){toast("Escribe el monto del ticket.");$("#exAmount").focus();return}
  const f=$("#exFile").files[0];let img="";
  const btn=$("#exSave");btn.disabled=true;btn.textContent="Guardando…";
  try{
    if(f){if(!f.type.startsWith("image/")){toast("Sube una foto (JPG o PNG) del ticket.");return}
      img=await compressImage(f);}
    await Store.set("expenses",uid(),{empId,date:$("#exDate").value||today,amount,concept:$("#exConcept").value,
      note:$("#exNote").value.trim(),img,createdAt:Date.now()});
    $("#exAmount").value="";$("#exNote").value="";$("#exFile").value="";
    toast("Viático guardado");
  }catch(e){if(e&&e.message==="img")toast("No se pudo leer la foto. Prueba con otra.")}
  finally{btn.disabled=false;btn.textContent="Guardar viático"}
});
[ "#exFilter","#exMonth"].forEach(s=>$(s).addEventListener("change",renderExpenses));
function renderExpenses(){
  const who=$("#exFilter").value,month=$("#exMonth").value;
  const list=Object.entries(S.expenses).map(([id,x])=>({id,...x}))
    .filter(x=>(!who||x.empId===who)&&(!month||String(x.date).startsWith(month)))
    .sort((a,b)=>(b.date||"").localeCompare(a.date||"")||(b.createdAt||0)-(a.createdAt||0));
  const box=$("#exList");
  if(!list.length){box.innerHTML='<div class="empty" style="grid-column:1/-1">No hay viáticos en este período.</div>';return}
  const total=list.reduce((s,x)=>s+(Number(x.amount)||0),0);
  box.innerHTML=`<div style="grid-column:1/-1;font-weight:600">${list.length} ticket${list.length>1?"s":""} · Total ${money(total)}</div>`+
  list.map(x=>`<div class="receipt" data-id="${esc(x.id)}">
    ${x.img?`<img src="${esc(x.img)}" alt="Ticket de ${esc(S.employees[x.empId]?.name||"")}" class="ex-img">`:'<div class="noimg">Sin foto</div>'}
    <div class="meta"><div class="amt">${money(x.amount)}</div>
      <div>${esc(S.employees[x.empId]?.name||"(persona eliminada)")}</div>
      <div class="sub">${esc(x.concept)} · ${esc(x.date)}${x.note?" · "+esc(x.note):""}</div>
      <button class="btn small danger ex-del" style="margin-top:8px">Eliminar</button></div></div>`).join("");
}
$("#exList").addEventListener("click",async e=>{
  if(e.target.classList.contains("ex-img")){$("#viewerImg").src=e.target.src;$("#viewer").showModal();return}
  if(e.target.classList.contains("ex-del")){
    if(!confirm("¿Eliminar este viático?"))return;
    await Store.del("expenses",e.target.closest(".receipt").dataset.id);toast("Viático eliminado");
  }
});

/* ---------- Informe ---------- */
function setMonth(){const d=new Date();$("#repFrom").value=isoDate(new Date(d.getFullYear(),d.getMonth(),1));$("#repTo").value=isoDate(new Date(d.getFullYear(),d.getMonth()+1,0))}
setMonth();
$("#repMonth").addEventListener("click",()=>{setMonth();renderReport()});
["#repFrom","#repTo"].forEach(s=>$(s).addEventListener("change",renderReport));
function reportData(){
  const from=$("#repFrom").value||"0000",to=$("#repTo").value||"9999";
  const inRange=d=>d>=from&&d<=to;
  const by={};const nameOf=id=>S.employees[id]?.name||"(persona eliminada)";
  const ensure=id=>by[id]||(by[id]={id,name:nameOf(id),days:0,lateDays:0,mins:0,disc:0,viat:0,tickets:0});
  sortedEmps().forEach(e=>ensure(e.id));
  const detail=[];
  Object.values(S.attendance).forEach(r=>{
    if(!inRange(r.date)||!r.arrival)return;
    const li=lateInfo(r,S.employees[r.empId]);const o=ensure(r.empId);
    o.days++;if(li.charged>0){o.lateDays++;o.mins+=li.charged;o.disc+=li.amount;
      detail.push({date:r.date,name:o.name,expected:li.expected,arrival:r.arrival,mins:li.charged,amount:li.amount})}
  });
  Object.values(S.expenses).forEach(x=>{if(!inRange(x.date))return;const o=ensure(x.empId);o.viat+=Number(x.amount)||0;o.tickets++});
  detail.sort((a,b)=>a.date.localeCompare(b.date)||a.name.localeCompare(b.name,"es"));
  return {rows:Object.values(by).sort((a,b)=>a.name.localeCompare(b.name,"es")),detail,from,to};
}
function renderReport(){
  const {rows,detail}=reportData();
  if(!rows.length){$("#repTable").innerHTML='<tr><td class="empty">Sin datos todavía.</td></tr>';$("#repDetail").innerHTML="";return}
  const t=rows.reduce((a,r)=>({mins:a.mins+r.mins,disc:a.disc+r.disc,viat:a.viat+r.viat}),{mins:0,disc:0,viat:0});
  $("#repTable").innerHTML=`<thead><tr><th>Persona</th><th class="num">Días marcados</th><th class="num">Días tarde</th><th class="num">Min. tarde</th><th class="num">Descuento</th><th class="num">Viáticos</th></tr></thead>
  <tbody>${rows.map(r=>`<tr><td>${esc(r.name)}</td><td class="num">${r.days}</td><td class="num">${r.lateDays}</td><td class="num">${r.mins}</td>
  <td class="num" style="color:${r.disc?"var(--late)":"inherit"}">${r.disc?"−"+money(r.disc):money(0)}</td><td class="num">${money(r.viat)}${r.tickets?` <span style="color:var(--muted)">(${r.tickets})</span>`:""}</td></tr>`).join("")}</tbody>
  <tfoot><tr><td>Total</td><td></td><td></td><td class="num">${t.mins}</td><td class="num">−${money(t.disc)}</td><td class="num">${money(t.viat)}</td></tr></tfoot>`;
  $("#repDetail").innerHTML=detail.length?`<thead><tr><th>Fecha</th><th>Persona</th><th>Entrada</th><th>Llegó</th><th class="num">Min.</th><th class="num">Descuento</th></tr></thead>
  <tbody>${detail.map(d=>`<tr><td>${esc(d.date)}</td><td>${esc(d.name)}</td><td>${esc(d.expected)}</td><td>${esc(d.arrival)}</td><td class="num">${d.mins}</td><td class="num">−${money(d.amount)}</td></tr>`).join("")}</tbody>`
  :'<tr><td class="empty">Nadie llegó tarde en este período.</td></tr>';
}
let downloads=null;
$("#repPrint").addEventListener("click",()=>window.print());
$("#repCsv").addEventListener("click",async()=>{
  const {rows,detail,from,to}=reportData();
  const q=v=>'"'+String(v).replace(/"/g,'""')+'"';
  const lines=[["Informe",from+" a "+to],[],["Persona","Dias marcados","Dias tarde","Minutos tarde","Descuento","Viaticos","Tickets"],
    ...rows.map(r=>[r.name,r.days,r.lateDays,r.mins,r.disc.toFixed(2),r.viat.toFixed(2),r.tickets]),[],
    ["Fecha","Persona","Entrada","Llego","Minutos","Descuento"],...detail.map(d=>[d.date,d.name,d.expected,d.arrival,d.mins,d.amount.toFixed(2)])];
  const csv="\uFEFF"+lines.map(l=>l.map(q).join(";")).join("\n");
  const filename=`informe_${from}_${to}.csv`;
  if(downloads){try{await downloads.save({filename,data:csv});}catch(e){toast("Descarga cancelada.")}return}
  saveBlob(filename,new Blob([csv],{type:"text/csv;charset=utf-8"}));
});

/* ---------- Extras ---------- */
const mon=s=>String(s||"").slice(0,7),fmt=m=>pad(Math.floor(m/60))+":"+pad(m%60),curDay=()=>isoDate(new Date()),num=v=>Number(v)||0;
const sum=(a,k)=>a.reduce((s,x)=>s+num(x[k]),0),r2=v=>Math.round(v*100)/100;
function saveBlob(name,blob){const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}
function readFile(f){if(f.type.startsWith("image/"))return compressImage(f);if(f.size>200000)return Promise.reject(new Error("big"));return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)})}
async function openFile(src){if(src.startsWith("data:image")){$("#viewerImg").src=src;$("#viewer").showModal()}else saveBlob("factura.pdf",await (await fetch(src)).blob())}
$("#cfDate").value=$("#fDate").value=$("#cDate").value=today;
$("#fMonth").value=$("#nMonth").value=$("#cMonth").value=today.slice(0,7);

/* Campo */
const campoCfg=()=>({n:3,a:"09:00",b:"17:00",field:{},...(S.settings.campo||{})});
function rnd(seed){let h=1779033703^seed.length;for(let i=0;i<seed.length;i++){h=Math.imul(h^seed.charCodeAt(i),3432918353);h=h<<13|h>>>19}
  return()=>{h=Math.imul(h^h>>>16,2246822507);h=Math.imul(h^h>>>13,3266489909);return((h^=h>>>16)>>>0)/4294967296}}
function slots(empId,date){const c=campoCfg(),r=rnd(date+empId),a=toMin(c.a),seg=(toMin(c.b)-a)/c.n;return Array.from({length:c.n},(_,i)=>Math.round(a+seg*i+r()*seg))}
function pending(id){const d=curDay(),done=Object.values(S.selfies).filter(s=>s.empId===id&&s.date===d).length;return{sl:slots(id,d),done}}
function drawSlots(){const id=$("#cfEmp").value;if(!id){$("#cfSlots").innerHTML="";return}
  const {sl,done}=pending(id),now=toMin(nowHM());
  $("#cfSlots").innerHTML='<label>Selfies de hoy</label>'+sl.map((m,i)=>i<done?`<span class="stamp ok">${fmt(m)} hecha</span>`:m<=now?`<span class="stamp late">${fmt(m)} pendiente</span>`:`<span class="stamp none">${fmt(m)}</span>`).join(" ")}
function renderCampo(){
  const c=campoCfg(),emps=sortedEmps(),keep=$("#cfEmp").value;
  $("#cfEmp").innerHTML=emps.length?emps.map(e=>`<option value="${esc(e.id)}">${esc(e.name)}${c.field[e.id]?" (campo)":""}</option>`).join(""):'<option value="">Agrega personal primero</option>';
  if(keep&&S.employees[keep])$("#cfEmp").value=keep;
  if(!["cfN","cfA","cfB"].includes(document.activeElement.id)){$("#cfN").value=c.n;$("#cfA").value=c.a;$("#cfB").value=c.b}
  $("#cfWho").innerHTML='<label>Personal de campo (a quienes se les piden selfies)</label>'+emps.map(e=>`<label style="display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:var(--ink)"><input type="checkbox" style="width:auto;min-height:0" data-id="${esc(e.id)}" ${c.field[e.id]?"checked":""}>${esc(e.name)}</label>`).join("");
  drawSlots();
  const d=$("#cfDate").value||curDay();
  const l=Object.entries(S.selfies).map(([id,s])=>({id,...s})).filter(s=>s.date===d).sort((a,b)=>a.ts-b.ts);
  $("#cfList").innerHTML=l.length?l.map(s=>`<div class="receipt" data-id="${esc(s.id)}"><img src="${esc(s.img)}" class="ex-img" alt="Selfie"><div class="meta"><div class="amt">${esc(S.employees[s.empId]?.name||"—")} · ${esc(s.time)}</div><div class="sub">${esc(s.place||"Sin lugar")}${s.lat?` · <a href="https://maps.google.com/?q=${s.lat},${s.lng}" target="_blank" rel="noopener">ver mapa</a>`:" · sin ubicación"}</div><button class="btn small danger sf-del" style="margin-top:8px">Eliminar</button></div></div>`).join(""):'<div class="empty" style="grid-column:1/-1">No hay selfies este día.</div>';
}
$("#cfEmp").addEventListener("change",drawSlots);
$("#cfDate").addEventListener("change",renderCampo);
$("#cfCfg").addEventListener("click",async()=>{const field={};document.querySelectorAll("#cfWho input").forEach(i=>{if(i.checked)field[i.dataset.id]=true});
  await Store.set("settings","campo",{n:Math.min(10,Math.max(1,parseInt($("#cfN").value)||3)),a:$("#cfA").value||"09:00",b:$("#cfB").value||"17:00",field});toast("Configuración guardada")});
$("#cfNotif").addEventListener("click",async()=>{if(!("Notification" in window)){toast("Este navegador no permite avisos.");return}toast((await Notification.requestPermission())==="granted"?"Avisos activados":"Avisos bloqueados")});
const notified={};
setInterval(()=>{const id=$("#cfEmp").value;if(!id||!campoCfg().field[id])return;drawSlots();const {sl,done}=pending(id),k=id+curDay()+done;
  if(sl.slice(done).some(m=>m<=toMin(nowHM()))&&!notified[k]){notified[k]=1;toast("Toca enviar una selfie");try{if(Notification.permission==="granted")new Notification("Selfie de campo",{body:"Envía tu selfie ahora."})}catch(e){}}},30000);
async function sendNetlify(rec,emp){if(!location.protocol.startsWith("http"))return;try{const fd=new FormData();fd.append("form-name","selfie");fd.append("empleado",emp.name);fd.append("lugar",rec.place||"");fd.append("hora",rec.date+" "+rec.time);fd.append("ubicacion",rec.lat?`https://maps.google.com/?q=${rec.lat},${rec.lng}`:"sin ubicación");fd.append("foto",await (await fetch(rec.img)).blob(),"selfie.jpg");await fetch("/",{method:"POST",body:fd})}catch(e){}}
$("#cfSave").addEventListener("click",async()=>{const id=$("#cfEmp").value,f=$("#cfFile").files[0];
  if(!id){toast("Elige la persona.");return}if(!f||!f.type.startsWith("image/")){toast("Toma una selfie primero.");return}
  const b=$("#cfSave");b.disabled=true;b.textContent="Enviando…";
  try{const img=await compressImage(f);
    const pos=await new Promise(r=>{if(!navigator.geolocation)return r(null);navigator.geolocation.getCurrentPosition(p=>r(p.coords),()=>r(null),{enableHighAccuracy:true,timeout:8000})});
    const rec={empId:id,date:curDay(),time:nowHM(),ts:Date.now(),place:$("#cfPlace").value.trim(),img,lat:pos?+pos.latitude.toFixed(5):0,lng:pos?+pos.longitude.toFixed(5):0};
    await Store.set("selfies",uid(),rec);$("#cfFile").value="";
    toast(pos?"Selfie enviada con ubicación":"Selfie enviada sin ubicación. Activa el GPS.")}
  catch(e){toast("No se pudo enviar la selfie.")}finally{b.disabled=false;b.textContent="Enviar selfie"}});
$("#cfList").addEventListener("click",async e=>{
  if(e.target.classList.contains("ex-img"))openFile(e.target.src);
  if(e.target.classList.contains("sf-del")&&confirm("¿Eliminar esta selfie?"))await Store.del("selfies",e.target.closest(".receipt").dataset.id)});

/* Facturas */
$("#fSave").addEventListener("click",async()=>{
  const base=num($("#fBase").value),prov=$("#fProv").value.trim();
  if(!prov){toast("Escribe el proveedor.");return}if(!(base>0)){toast("Escribe el valor sin IVA.");return}
  const f=$("#fFile").files[0],b=$("#fSave");b.disabled=true;
  try{const img=f?await readFile(f):"",iva=r2(base*num($("#fIva").value)/100);
    await Store.set("invoices",uid(),{date:$("#fDate").value||today,prov,ruc:$("#fRuc").value.trim(),num:$("#fNum").value.trim(),base,iva,total:r2(base+iva),cat:$("#fCat").value,ded:$("#fDed").checked,img,createdAt:Date.now()});
    ["#fProv","#fRuc","#fNum","#fBase"].forEach(s=>$(s).value="");$("#fFile").value="";toast("Factura guardada")}
  catch(e){toast(e&&e.message==="big"?"El PDF pesa más de 200 KB. Sube una foto.":"No se pudo guardar.")}finally{b.disabled=false}});
$("#fMonth").addEventListener("change",renderFact);
function renderFact(){
  const m=$("#fMonth").value,l=Object.entries(S.invoices).map(([id,x])=>({id,...x})).filter(x=>!m||mon(x.date)===m).sort((a,b)=>b.date.localeCompare(a.date));
  const t={b:sum(l,"base"),i:sum(l,"iva"),t:sum(l,"total")};
  $("#fTable").innerHTML=l.length?`<thead><tr><th>Fecha</th><th>Proveedor</th><th>Categoría</th><th class="num">Base</th><th class="num">IVA</th><th class="num">Total</th><th>Deducible</th><th></th></tr></thead><tbody>${l.map(x=>`<tr data-id="${esc(x.id)}"><td>${esc(x.date)}</td><td>${esc(x.prov)}<br><span style="color:var(--muted)">${esc(x.num)}</span></td><td>${esc(x.cat)}</td><td class="num">${money(x.base)}</td><td class="num">${money(x.iva)}</td><td class="num">${money(x.total)}</td><td><input type="checkbox" class="f-ded" style="width:auto;min-height:0" aria-label="Deducible" ${x.ded?"checked":""}></td><td>${x.img?'<button class="btn small ghost f-view">Ver</button> ':""}<button class="btn small danger f-del">Quitar</button></td></tr>`).join("")}</tbody><tfoot><tr><td colspan="3">Total</td><td class="num">${money(t.b)}</td><td class="num">${money(t.i)}</td><td class="num">${money(t.t)}</td><td colspan="2"></td></tr></tfoot>`:'<tr><td class="empty">No hay facturas en este mes.</td></tr>';
}
$("#fTable").addEventListener("click",async e=>{const tr=e.target.closest("tr[data-id]");if(!tr)return;const id=tr.dataset.id,x=S.invoices[id];
  if(e.target.classList.contains("f-view"))openFile(x.img);
  if(e.target.classList.contains("f-del")&&confirm("¿Quitar esta factura?"))await Store.del("invoices",id)});
$("#fTable").addEventListener("change",async e=>{if(!e.target.classList.contains("f-ded"))return;const id=e.target.closest("tr").dataset.id;await Store.set("invoices",id,{...S.invoices[id],ded:e.target.checked})});
$("#fXls").addEventListener("click",()=>{$("#cMonth").value=$("#fMonth").value;xls()});

/* Nómina */
const nCfg=()=>({p:9.45,e:11.15,sbu:0,fr:"0",...(S.settings.nomina||{})});
function payroll(m){const c=nCfg();return sortedEmps().map(e=>{const sal=num(S.salaries[e.id]?.v);let late=0;
  Object.values(S.attendance).forEach(r=>{if(r.empId===e.id&&mon(r.date)===m&&r.arrival)late+=lateInfo(r,e).amount});
  const base=Math.max(0,sal-late),ip=base*c.p/100,pe=base*c.e/100,d13=base/12,d14=num(c.sbu)/12,fr=c.fr==="1"?base*0.0833:0;
  return{id:e.id,name:e.name,sal,late,ip,neto:base-ip,pe,d13,d14,fr,costo:base+pe+d13+d14+fr}})}
$("#nMonth").addEventListener("change",renderNom);
document.querySelectorAll(".n-cfg").forEach(i=>i.addEventListener("change",async()=>{
  await Store.set("settings","nomina",{p:num($("#nP").value),e:num($("#nE").value),sbu:num($("#nS").value),fr:$("#nF").value});toast("Guardado")}));
function renderNom(){const c=nCfg();
  if(!document.activeElement.classList.contains("n-cfg")){$("#nP").value=c.p;$("#nE").value=c.e;$("#nS").value=c.sbu;$("#nF").value=c.fr}
  const l=payroll($("#nMonth").value);
  const T=k=>money(l.reduce((a,r)=>a+r[k],0));
  $("#nTable").innerHTML=l.length?`<thead><tr><th>Persona</th><th>Sueldo</th><th class="num">Atrasos</th><th class="num">IESS personal</th><th class="num">Neto a pagar</th><th class="num">IESS patronal</th><th class="num">13.º</th><th class="num">14.º</th><th class="num">F. reserva</th><th class="num">Costo empresa</th></tr></thead><tbody>${l.map(r=>`<tr data-id="${esc(r.id)}"><td>${esc(r.name)}</td><td><input type="number" class="n-sal" min="0" step="0.01" value="${r.sal||""}" style="width:100px;min-height:36px" aria-label="Sueldo de ${esc(r.name)}"></td><td class="num">${r.late?"−"+money(r.late):money(0)}</td><td class="num">${money(r.ip)}</td><td class="num"><strong>${money(r.neto)}</strong></td><td class="num">${money(r.pe)}</td><td class="num">${money(r.d13)}</td><td class="num">${money(r.d14)}</td><td class="num">${money(r.fr)}</td><td class="num">${money(r.costo)}</td></tr>`).join("")}</tbody><tfoot><tr><td>Total</td><td></td><td class="num">${T("late")}</td><td class="num">${T("ip")}</td><td class="num">${T("neto")}</td><td class="num">${T("pe")}</td><td class="num">${T("d13")}</td><td class="num">${T("d14")}</td><td class="num">${T("fr")}</td><td class="num">${T("costo")}</td></tr></tfoot>`:'<tr><td class="empty">Agrega personal en la pestaña Personal.</td></tr>';
}
$("#nTable").addEventListener("change",async e=>{if(!e.target.classList.contains("n-sal"))return;const id=e.target.closest("tr").dataset.id;await Store.set("salaries",id,{v:num(e.target.value)});toast("Sueldo guardado")});

/* Contabilidad */
function summary(m){const inc=Object.entries(S.income).map(([id,x])=>({id,...x})).filter(x=>mon(x.date)===m).sort((a,b)=>b.date.localeCompare(a.date)),
  inv=Object.values(S.invoices).filter(x=>mon(x.date)===m),ded=inv.filter(x=>x.ded),pr=payroll(m),
  s={inc,inv,pr,ing:sum(inc,"base"),ivaC:sum(inc,"iva"),gb:sum(ded,"base"),ivaK:sum(ded,"iva"),nd:sum(inv.filter(x=>!x.ded),"total"),nom:sum(pr,"costo")};
  s.util=s.ing-s.gb-s.nom;s.ivaP=s.ivaC-s.ivaK;return s}
$("#cMonth").addEventListener("change",renderConta);
$("#cAdd").addEventListener("click",async()=>{const base=num($("#cBase").value);if(!(base>0)){toast("Escribe el valor sin IVA.");return}
  const iva=r2(base*num($("#cIva").value)/100);
  await Store.set("income",uid(),{date:$("#cDate").value||today,client:$("#cClient").value.trim(),concept:$("#cConcept").value.trim(),base,iva,total:r2(base+iva)});
  ["#cClient","#cConcept","#cBase"].forEach(s=>$(s).value="");toast("Ingreso registrado")});
function renderConta(){const s=summary($("#cMonth").value);
  const rows=[["Ingresos (sin IVA)",s.ing],["Gastos deducibles (sin IVA)",s.gb],["Costo de nómina",s.nom],["Utilidad del mes",s.util],["IVA cobrado en ventas",s.ivaC],["IVA pagado en compras deducibles",s.ivaK],["IVA por pagar (estimado)",s.ivaP],["Gastos no deducibles (total)",s.nd]];
  $("#cSum").innerHTML='<tbody>'+rows.map((r,i)=>`<tr><td${i===3?' style="font-weight:700"':""}>${r[0]}</td><td class="num"${i===3?` style="font-weight:700;color:${r[1]<0?"var(--late)":"var(--ok)"}"`:""}>${money(r[1])}</td></tr>`).join("")+'</tbody>';
  $("#cInc").innerHTML=s.inc.length?`<thead><tr><th>Fecha</th><th>Cliente</th><th>Concepto</th><th class="num">Base</th><th class="num">IVA</th><th class="num">Total</th><th></th></tr></thead><tbody>${s.inc.map(x=>`<tr data-id="${esc(x.id)}"><td>${esc(x.date)}</td><td>${esc(x.client)}</td><td>${esc(x.concept)}</td><td class="num">${money(x.base)}</td><td class="num">${money(x.iva)}</td><td class="num">${money(x.total)}</td><td><button class="btn small danger c-del">Quitar</button></td></tr>`).join("")}</tbody>`:'<tr><td class="empty">Sin ingresos registrados este mes.</td></tr>';
}
$("#cInc").addEventListener("click",async e=>{if(e.target.classList.contains("c-del")&&confirm("¿Quitar este ingreso?"))await Store.del("income",e.target.closest("tr").dataset.id)});
function xls(){if(!window.XLSX){toast("Excel no se cargó. Recarga la página.");return}
  const m=$("#cMonth").value,s=summary(m),wb=XLSX.utils.book_new(),add=(n,rows)=>XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(rows),n);
  add("Resumen",[["Mes",m],["Ingresos (sin IVA)",r2(s.ing)],["Gastos deducibles (sin IVA)",r2(s.gb)],["Costo de nómina",r2(s.nom)],["Utilidad",r2(s.util)],["IVA cobrado",r2(s.ivaC)],["IVA en compras deducibles",r2(s.ivaK)],["IVA por pagar (estimado)",r2(s.ivaP)],["Gastos no deducibles",r2(s.nd)],["Viáticos del mes",r2(sum(Object.values(S.expenses).filter(x=>mon(x.date)===m),"amount"))]]);
  add("Facturas",[["Fecha","Proveedor","RUC","N.º","Categoría","Base","IVA","Total","Deducible"],...s.inv.map(x=>[x.date,x.prov,x.ruc,x.num,x.cat,x.base,x.iva,x.total,x.ded?"Sí":"No"])]);
  add("Ingresos",[["Fecha","Cliente","Concepto","Base","IVA","Total"],...s.inc.map(x=>[x.date,x.client,x.concept,x.base,x.iva,x.total])]);
  add("Nómina",[["Persona","Sueldo","Atrasos","IESS personal","Neto a pagar","IESS patronal","13.º","14.º","Fondos reserva","Costo empresa"],...s.pr.map(r=>[r.name,r.sal,r.late,r.ip,r.neto,r.pe,r.d13,r.d14,r.fr,r.costo].map((v,i)=>i?r2(v):v))]);
  add("Asistencia",[["Fecha","Persona","Entrada","Llegó","Min. tarde","Descuento"],...Object.values(S.attendance).filter(r=>mon(r.date)===m&&r.arrival).sort((a,b)=>a.date.localeCompare(b.date)).map(r=>{const li=lateInfo(r,S.employees[r.empId]);return[r.date,S.employees[r.empId]?.name||"",li.expected,r.arrival,li.charged,r2(li.amount)]})]);
  add("Viáticos",[["Fecha","Persona","Concepto","Detalle","Monto"],...Object.values(S.expenses).filter(x=>mon(x.date)===m).sort((a,b)=>a.date.localeCompare(b.date)).map(x=>[x.date,S.employees[x.empId]?.name||"",x.concept,x.note||"",x.amount])]);
  add("Selfies",[["Fecha","Hora","Persona","Lugar","Mapa"],...Object.values(S.selfies).filter(x=>mon(x.date)===m).sort((a,b)=>a.ts-b.ts).map(x=>[x.date,x.time,S.employees[x.empId]?.name||"",x.place||"",x.lat?`https://maps.google.com/?q=${x.lat},${x.lng}`:""])]);
  XLSX.writeFile(wb,`contabilidad_${m}.xlsx`)}
$("#cXls").addEventListener("click",xls);

/* ---------- Render ---------- */
function renderAll(){fillSelects();renderAttendance();renderExpenses();renderReport();renderPeople();renderCampo();renderFact();renderNom();renderConta()}

/* ---------- Inicio ---------- */
renderAll();if(!window.__db)Store.loadLocal().then(renderAll);
$("#status").textContent="Guardando en este dispositivo.";
(async()=>{
  let db=window.__db||null;
  if(!db)return;
  Store.mode="db";Store.db=db;COLS.forEach(c=>S[c]={});
  $("#status").textContent="Datos compartidos: todos los que abren este enlace ven lo mismo.";
  COLS.forEach(c=>db.collection(c).onSnapshot(snap=>{
    const o={};snap.docs.forEach(d=>{o[d.id]=d.data()});S[c]=o;renderAll();
  },()=>{$("#status").textContent="Sin conexión con los datos compartidos. Recarga la página."}));
})();
})();
