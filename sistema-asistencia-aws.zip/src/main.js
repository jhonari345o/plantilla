import { Amplify } from "aws-amplify";
import { signIn, signOut, confirmSignIn, fetchAuthSession, getCurrentUser } from "aws-amplify/auth";
import { generateClient } from "aws-amplify/data";
import outputs from "../amplify_outputs.json";

Amplify.configure(outputs);
const $ = (s) => document.querySelector(s);

function login() {
  return new Promise((resolve) => {
    const L = $("#login"), err = $("#lgErr");
    L.hidden = false;
    let step = 1;
    $("#lgBtn").onclick = async () => {
      err.textContent = "";
      const b = $("#lgBtn");
      b.disabled = true;
      try {
        const r = step === 1
          ? await signIn({ username: $("#lgUser").value.trim(), password: $("#lgPass").value })
          : await confirmSignIn({ challengeResponse: $("#lgNew").value });
        const s = r.nextStep && r.nextStep.signInStep;
        if (s === "CONFIRM_SIGN_IN_WITH_NEW_PASSWORD_REQUIRED") {
          step = 2;
          $("#lgStep1").hidden = true;
          $("#lgStep2").hidden = false;
          b.textContent = "Guardar contraseña";
        } else if (r.isSignedIn) { L.hidden = true; resolve(); }
        else err.textContent = "No se pudo completar el ingreso.";
      } catch (e) {
        if (e.name === "UserAlreadyAuthenticatedException") { L.hidden = true; resolve(); }
        else err.textContent = e.name === "NotAuthorizedException" ? "Correo o contraseña incorrectos." : "No se pudo ingresar. Revisa los datos.";
      } finally { b.disabled = false; }
    };
  });
}

const PRIV = ["invoices", "income", "salaries"];
const COLS = ["employees", "attendance", "expenses", "settings", "selfies", ...PRIV];
const p2 = (n) => String(n).padStart(2, "0");
const parse = (s) => { try { return JSON.parse(s); } catch (e) { return null; } };

function makeDb(admin) {
  const M = generateClient().models;
  const raw = {}, cache = {}, listeners = {};
  const rid = (it) => it.id.slice(it.col.length + 1);
  const modelOf = (col) =>
    PRIV.includes(col) ? "Private" : col === "employees" ? "Roster" : col === "settings" ? "Config"
      : col === "attendance" ? (admin ? "Private" : "Staff") : "Staff";
  const snap = (c) => ({ docs: Object.entries(cache[c] || {}).map(([id, d]) => ({ id, data: () => d })) });

  function uidOf(empId) {
    const it = (raw.Roster || []).find((x) => x.col === "employees" && rid(x) === empId);
    const d = it && parse(it.json);
    return d && d.uid ? d.uid : "";
  }

  // Hora, fecha, persona y descuento de lo que registran los empleados salen del SERVIDOR,
  // no de lo que envíe el navegador.
  function rebuild() {
    const out = {}, first = {}, uidMap = {};
    const put = (c, k, d) => { (out[c] ||= {})[k] = d; };
    (raw.Roster || []).forEach((it) => {
      const d = parse(it.json); if (!d) return;
      put("employees", rid(it), d);
      if (d.uid) uidMap[d.uid] = rid(it);
    });
    (raw.Config || []).forEach((it) => { const d = parse(it.json); if (d) put(it.col, rid(it), d); });
    (raw.Staff || []).forEach((it) => {
      const d = parse(it.json); if (!d) return;
      const emp = uidMap[String(it.ownerId || "").split("::").pop()];
      if (emp) d.empId = emp;
      if (it.col === "attendance" || it.col === "selfies") {
        if (!emp) return;
        const t = new Date(it.createdAt);
        d.date = t.getFullYear() + "-" + p2(t.getMonth() + 1) + "-" + p2(t.getDate());
        d.time = p2(t.getHours()) + ":" + p2(t.getMinutes());
        d.ts = t.getTime();
        if (it.col === "attendance") {
          d.arrival = d.time; d._srv = true;
          const k = d.date + "_" + emp;
          if (first[k] && first[k] <= d.ts) return;
          first[k] = d.ts;
          put("attendance", k, d);
          return;
        }
      }
      put(it.col, rid(it), d);
    });
    (raw.Private || []).forEach((it) => { const d = parse(it.json); if (d) put(it.col, rid(it), d); });
    COLS.forEach((c) => { cache[c] = out[c] || {}; (listeners[c] || []).forEach((f) => f(snap(c))); });
  }

  function watch(name) {
    M[name].observeQuery().subscribe({ next: ({ items }) => { raw[name] = items; rebuild(); }, error: () => {} });
  }
  ["Staff", "Roster", "Config"].forEach(watch);
  if (admin) watch("Private");

  const fail = (r) => Object.assign(new Error("db"), { code: /Unauthorized/i.test(JSON.stringify(r.errors || "")) ? "permission_denied" : "error" });
  return {
    collection: (col) => ({
      doc: (r) => ({
        async set(data) {
          const name = modelOf(col), id = col + "#" + r, input = { id, col, json: JSON.stringify(data) };
          if (admin && name === "Staff") { const u = uidOf(data.empId); if (u) input.ownerId = u; }
          if (admin && name === "Roster" && data.uid) input.ownerId = data.uid;
          let res = await M[name].update(input);
          if (!res.data) res = await M[name].create(input);
          if (!res.data) throw fail(res);
          const old = (raw[name] || []).find((x) => x.id === id);
          raw[name] = (raw[name] || []).filter((x) => x.id !== id).concat({ ...input, createdAt: old ? old.createdAt : new Date().toISOString() });
          rebuild();
        },
        async delete() {
          const id = col + "#" + r, names = [modelOf(col)];
          if (col === "attendance") names.push("Staff");
          const rs = await Promise.all(names.map((n) => M[n].delete({ id })));
          if (rs.every((x) => !x.data && x.errors && x.errors.length)) throw fail(rs[0]);
          names.forEach((n) => { raw[n] = (raw[n] || []).filter((x) => x.id !== id); });
          rebuild();
        },
      }),
      onSnapshot(next) {
        (listeners[col] ||= []).push(next);
        next(snap(col));
        return () => {};
      },
    }),
  };
}

try { await getCurrentUser(); } catch (e) { await login(); }
const session = await fetchAuthSession();
const groups = session.tokens?.accessToken?.payload["cognito:groups"] || [];
const admin = groups.includes("admin");
document.body.classList.toggle("staff", !admin);
window.__db = makeDb(admin);
await import("./app.js");
$("#logout").onclick = async () => { await signOut(); location.reload(); };
